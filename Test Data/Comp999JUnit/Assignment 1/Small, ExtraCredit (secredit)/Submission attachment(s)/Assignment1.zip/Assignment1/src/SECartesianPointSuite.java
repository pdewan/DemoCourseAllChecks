package gradingTools.comp999junit.assignment1.testables.secredit;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

//@RunWith(Suite.class)
@RunWith(Suite.class)
@Suite.SuiteClasses({
   SECPointAngleZeroDegreeTest.class,
//   APointAngleZeroDegreeTest.class,
//   APointAngleNinetyDegreeTest.class,
//   APointAngleFortyFiveDegreeTest.class,
//   APointAngleMinusNinetyDegreeTest.class,
   SECPointRadiusTest.class,
   
})
public class SECartesianPointSuite {
//	public static final String ANGLE_TESTS = "Angle Tests";

	

}

